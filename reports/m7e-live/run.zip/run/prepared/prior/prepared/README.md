# Offline QA Judge Revision

Prepared 60 exact v2 judge requests over saved answers. No new answers, API calls or v2 model judgments were produced.

Judge-only proposal: gpt-5.4-mini-2026-03-17; estimated US$2.133403. This is not a billing cap or approval. Prior generation costs are excluded.

Plan fingerprint: `28bf7b780982b17d37150c1c4bad1e717769832faddd6e59ce24edbc656324f7`.

The replay file is a schema/validator migration diagnostic on exposed v1 outputs. Only rubric_id is retagged in memory. No source IDs, scores, claims or labels are repaired. Schema acceptance is not future model compliance or semantic accuracy. Source files remain copied verbatim.

This milestone has no v2 execution command. Any later judge-only run needs explicit model, scope and budget approval. The v1 combined runner cannot execute this bundle.
